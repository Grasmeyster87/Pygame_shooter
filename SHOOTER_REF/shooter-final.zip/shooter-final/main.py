import pygame
from game import Game

pygame.init()

game = Game()
game.run()

pygame.quit()
